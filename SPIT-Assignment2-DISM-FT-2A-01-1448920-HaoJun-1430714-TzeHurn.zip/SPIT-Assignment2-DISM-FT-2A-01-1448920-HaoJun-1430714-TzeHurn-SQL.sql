CREATE DATABASE  IF NOT EXISTS `spit` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `spit`;
-- MySQL dump 10.13  Distrib 5.6.13, for Win32 (x86)
--
-- Host: localhost    Database: spit
-- ------------------------------------------------------
-- Server version	5.6.17

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `cardtype`
--

DROP TABLE IF EXISTS `cardtype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cardtype` (
  `cardtypeid` int(11) NOT NULL AUTO_INCREMENT,
  `cardtype` varchar(45) NOT NULL,
  PRIMARY KEY (`cardtypeid`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cardtype`
--

LOCK TABLES `cardtype` WRITE;
/*!40000 ALTER TABLE `cardtype` DISABLE KEYS */;
INSERT INTO `cardtype` VALUES (1,'Visa'),(2,'MasterCard'),(4,'America Express'),(5,'Diners Club');
/*!40000 ALTER TABLE `cardtype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cart`
--

DROP TABLE IF EXISTS `cart`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cart` (
  `cartid` int(11) NOT NULL AUTO_INCREMENT,
  `memid` int(11) NOT NULL,
  PRIMARY KEY (`cartid`),
  KEY `memid_idx` (`memid`),
  CONSTRAINT `member_memid` FOREIGN KEY (`memid`) REFERENCES `member` (`memid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cart`
--

LOCK TABLES `cart` WRITE;
/*!40000 ALTER TABLE `cart` DISABLE KEYS */;
INSERT INTO `cart` VALUES (22,37);
/*!40000 ALTER TABLE `cart` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cart_has_product`
--

DROP TABLE IF EXISTS `cart_has_product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cart_has_product` (
  `cartid` int(11) NOT NULL,
  `prodid` int(11) NOT NULL,
  `catid` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  PRIMARY KEY (`cartid`,`prodid`,`catid`),
  KEY `cart_prodid_idx` (`prodid`),
  KEY `cart_catid_idx` (`catid`),
  CONSTRAINT `cart_cartid` FOREIGN KEY (`cartid`) REFERENCES `cart` (`cartid`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `cart_catid` FOREIGN KEY (`catid`) REFERENCES `product` (`catid`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `cart_prodid` FOREIGN KEY (`prodid`) REFERENCES `product` (`prodid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cart_has_product`
--

LOCK TABLES `cart_has_product` WRITE;
/*!40000 ALTER TABLE `cart_has_product` DISABLE KEYS */;
INSERT INTO `cart_has_product` VALUES (22,5,3,5);
/*!40000 ALTER TABLE `cart_has_product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category` (
  `catid` int(11) NOT NULL AUTO_INCREMENT,
  `catname` varchar(45) NOT NULL,
  `imgpath` varchar(45) NOT NULL,
  PRIMARY KEY (`catid`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (1,'Laptops','images/lap_hp_pavilion.jpg'),(3,'Memory','images/mem_4GB_Cruzer_drive.jpg'),(7,'TV','images/tv_panasonic_uhd_tv.jpg'),(10,'Audio','images/audio_CX100.jpg'),(12,'Internal Component','images/ic_gigabyte_X58A_UD7.jpg'),(13,'Cellphones','images/hp_samsung_galaxy_note4.jpg'),(14,'Monitors','images/mon_Minimalist_FHD.jpg'),(15,'Mouse and Keyboard','images/kbm_GRIP_500.jpg');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comments`
--

DROP TABLE IF EXISTS `comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(60) DEFAULT NULL,
  `name` varchar(45) NOT NULL,
  `comment` varchar(500) NOT NULL,
  `prodid` int(11) NOT NULL,
  `ratings` varchar(45) NOT NULL,
  `catid` int(11) NOT NULL,
  `datetime` varchar(30) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `prodid_idx` (`prodid`),
  KEY `com_catid_idx` (`catid`),
  CONSTRAINT `com_catid` FOREIGN KEY (`catid`) REFERENCES `category` (`catid`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `com_prodid` FOREIGN KEY (`prodid`) REFERENCES `product` (`prodid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=159 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comments`
--

LOCK TABLES `comments` WRITE;
/*!40000 ALTER TABLE `comments` DISABLE KEYS */;
INSERT INTO `comments` VALUES (1,NULL,'Anon245','So, so... Nothing very special about the laptop. Pretty Heavy as well. Doing just fine with it though.',1,'3 Star',1,'2015-05-24 20:56:21'),(2,NULL,'Anon333','Light and pretty special! I\'m enjoying its company so far!! :))',2,'4 Star',1,'2015-05-24 20:57:34'),(3,NULL,'Jon123','I can store anything in it!! AMAZING!!',5,'5 Star',3,'2015-05-24 20:58:55'),(4,NULL,'Jess4567','Portable and the amount of space it gives suits me perfectly. Should reduce the price though.',6,'4 Star',3,'2015-05-24 21:00:26'),(5,NULL,'Anon','Watching Movies have never felt so amazing. The feeling this TV gives simply amazes me!!',7,'5 Star',7,'2015-05-24 21:01:22'),(6,NULL,'Diego','This TV makes me feel like im in a cinema all the time. Amazing!',8,'5 Star',7,'2015-05-24 21:02:07'),(7,NULL,'SuperGuy2','Not the best of sound effects... Prefer my apple earphone',12,'2 Star',10,'2015-05-24 21:03:14'),(8,NULL,'Ralph','Pretty good, makes me feel like im in the club :))',13,'4 Star',10,'2015-05-24 21:03:50'),(9,NULL,'Wolverine3','VERY VERY GOOOOOODDDD!!!',9,'5 Star',12,'2015-05-24 21:04:45'),(10,NULL,'Jacky','Worth my money ',10,'5 Star',12,'2015-05-24 21:05:19'),(11,NULL,'Jonas','Love Samsung and still do because of products like this',3,'4 Star',13,'2015-05-24 21:06:04'),(13,NULL,'Kimmy','Spoil too easily...',14,'1 Star',14,'2015-05-24 21:07:53'),(14,NULL,'Ethan','Works great, feels good!',15,'4 Star',14,'2015-05-24 21:08:18'),(15,NULL,'LavaBoy77','Love the sound whenever i push its buttons!!! xoxo',16,'4 Star',15,'2015-05-24 21:09:14'),(16,NULL,'HappyGirl99','Im becoming a pro-gamer now thanks to this mouse!',17,'5 Star',15,'2015-05-24 21:09:43'),(17,NULL,'Gamer123456','Gaming never felt the same again :)',18,'5 Star',15,'2015-05-24 21:10:14'),(149,NULL,'John','Today is great',3,'2 Star',13,'2015-05-26 09:50:21'),(150,NULL,'Kenny','Too good, very fast and good performance',10,'4 Star',12,'2015-07-10 15:05:39'),(153,NULL,'Jenny','Too cool to be true.!!&!',10,'5 Star',12,'2015-07-10 15:07:38'),(158,NULL,'Lenny','Poor performance, bulky packaging',9,'1 Star',12,'2015-07-10 15:13:38');
/*!40000 ALTER TABLE `comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `confirmpurchase`
--

DROP TABLE IF EXISTS `confirmpurchase`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `confirmpurchase` (
  `confirmpurchaseID` int(11) NOT NULL AUTO_INCREMENT,
  `memid` int(11) NOT NULL,
  PRIMARY KEY (`confirmpurchaseID`)
) ENGINE=InnoDB AUTO_INCREMENT=308 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `confirmpurchase`
--

LOCK TABLES `confirmpurchase` WRITE;
/*!40000 ALTER TABLE `confirmpurchase` DISABLE KEYS */;
INSERT INTO `confirmpurchase` VALUES (280,34),(281,34),(282,34),(283,34),(284,34),(285,34),(286,34),(287,34),(288,34),(289,34),(290,34),(291,37),(292,37),(293,37),(294,37),(295,37),(296,37),(297,37),(298,37),(299,37),(300,37),(301,37),(302,37),(303,37),(304,37),(305,37),(306,37),(307,37);
/*!40000 ALTER TABLE `confirmpurchase` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coupons`
--

DROP TABLE IF EXISTS `coupons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `coupons` (
  `vid` int(11) NOT NULL AUTO_INCREMENT,
  `memid` int(11) NOT NULL,
  `vcode` varchar(6) NOT NULL,
  `vcollect` varchar(30) NOT NULL,
  PRIMARY KEY (`vid`),
  KEY `coupon_memid_idx` (`memid`),
  CONSTRAINT `coupon_memid` FOREIGN KEY (`memid`) REFERENCES `member` (`memid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coupons`
--

LOCK TABLES `coupons` WRITE;
/*!40000 ALTER TABLE `coupons` DISABLE KEYS */;
INSERT INTO `coupons` VALUES (21,25,'W46GvQ','2015-07-25 18:43:37'),(24,34,'79zjwL','2015-08-10 20:01:24'),(25,37,'3lGyU4','2015-08-10 22:08:55');
/*!40000 ALTER TABLE `coupons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `crypt`
--

DROP TABLE IF EXISTS `crypt`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `crypt` (
  `email` varchar(60) NOT NULL,
  `enpass` varbinary(50) NOT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `crypt`
--

LOCK TABLES `crypt` WRITE;
/*!40000 ALTER TABLE `crypt` DISABLE KEYS */;
INSERT INTO `crypt` VALUES ('haojunster@gmail.com','ZlYHg<'),('slypoon@gmail.com','ZlYHg<');
/*!40000 ALTER TABLE `crypt` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login`
--

DROP TABLE IF EXISTS `login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `login` (
  `loginid` varchar(50) NOT NULL,
  `password` varchar(30) NOT NULL,
  PRIMARY KEY (`loginid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login`
--

LOCK TABLES `login` WRITE;
/*!40000 ALTER TABLE `login` DISABLE KEYS */;
INSERT INTO `login` VALUES ('root','abc123'),('test','123');
/*!40000 ALTER TABLE `login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member` (
  `memid` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(60) NOT NULL,
  `password` varchar(45) NOT NULL,
  `name` varchar(45) NOT NULL,
  `gender` varchar(6) NOT NULL,
  `dobday` int(2) NOT NULL,
  `dobmonth` varchar(45) NOT NULL,
  `dobyear` int(4) NOT NULL,
  `address` varchar(100) NOT NULL,
  `contactno` int(10) NOT NULL,
  `subscribe` varchar(3) NOT NULL,
  `joindate` varchar(30) NOT NULL,
  PRIMARY KEY (`memid`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` VALUES (22,'maytime@hotmail.com','ABC!@#123','Jesslyn','female',14,'May',1980,'Blk 67 Jurong West Ave 5 #09-175 Singapore 630067',83324169,'yes',''),(24,'thamricky@gmail.com','ABC!@#123','Ricky Tham','male',17,'December',1971,'Blk 137 Tampines West Ave 5 #19-175 Singapore 530137',93310247,'no',''),(25,'rachelyang@msn.com','ASD$%^456','Rachel Yang','female',14,'July',1999,'Blk 78 Pasir Panjang Street 88 Singapore 26078',95512347,'yes',''),(26,'pungjenifer@live.com','GHJ567%^&','Jenifer Pung','female',5,'November',1980,'Blk 78 Telok Blangah Street 88 Singapore 26078',95512347,'no',''),(28,'janicewee@hotmail.com','!Q23WE4r','Janice Wee','female',17,'October',1992,'Blk 54 Eunos Street 22 Singapore 03054',96632140,'yes',''),(30,'ginateo@noc.com','!Q@#WE4r5t','Gina Teo','female',13,'May',1982,'Blk 45 Tampines Street 6 Singapore 73045',94451728,'no',''),(31,'chasetan@gmail.com','!Q@#WE4r','Chase Tan','male',31,'March',1996,'Blk 77 Changi South Street 2 #07-567',87723450,'yes','2015-07-22 12:10:24'),(34,'slypoon@gmail.com','ZlYHg<','Sly Poon','male',17,'September',1996,'Blk 76 Bedok South Ave 3 #07-1755',81163328,'yes','2015-08-04 10:38:34'),(37,'haojunster@gmail.com','ZlYHg<','Hao Jun','male',15,'September',1993,'Blk 83 Fengshan Street 5 #09-1137',86632046,'yes','2015-08-10 20:53:08');
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product` (
  `prodid` int(11) NOT NULL AUTO_INCREMENT,
  `catid` int(11) NOT NULL,
  `brand` varchar(45) NOT NULL,
  `prodname` varchar(45) NOT NULL,
  `description` varchar(100) NOT NULL,
  `spec1` varchar(200) NOT NULL,
  `spec2` varchar(100) NOT NULL,
  `spec3` varchar(100) NOT NULL,
  `spec4` varchar(100) NOT NULL,
  `price` int(11) NOT NULL,
  `imgpath` varchar(45) NOT NULL DEFAULT 'images/default.jpg',
  `quantity` int(11) NOT NULL,
  PRIMARY KEY (`prodid`,`catid`),
  KEY `catid_idx` (`catid`),
  CONSTRAINT `catid` FOREIGN KEY (`catid`) REFERENCES `category` (`catid`) ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (1,1,'Asus','N56VB-S4041H-16GB','Asus Next Gen Laptop','Processor: Intel® Core™ i7-3630QM Quad Core (2.4 GHz, Intel Ivy Bridge Architecture, 6 MB L3 cache, Features Intel Turbo Boost up to 3.4GHz)','Display: 15.6\" (ASUS, 1920x1080 Full HD Resolution)','Memory: 16GB (DDR3 1600MHZ)','Hard Disk Drive: 750GB',1299,'images/lap_asus.jpg',17),(2,1,'HP','N56VB-S4041H-16GB','HP Next Gen Laptop','Processor: 2nd generation Intel(R) Core(TM) i7-2670QM (2.2 GHz, 6MB L3 Cache) with Turbo Boost up to 3.1 GHz','Display: 15.6\" High Definition HP LED Brightview (1366x768)','Memory: 4GB DDR3 System Memory (1 Dimm)','Hard drive: 750GB',1399,'images/lap_hp_pavilion.jpg',19),(3,13,'Samsung','Galaxy Note 4','Samsung Next Gen Smartphone','Dimension: 153.5 X 78.6 X 8.5 mm / 176g','Memory: 3GB RAM + 32GB Internal memory. Supports microSD up to 128GB','Battery: 3220mAh Fast Charging','S Pen: 15g, Hovering 15mm, Pressure level 2,048',900,'images/hp_samsung_galaxy_note4.jpg',4),(4,13,'Sony','Xperia Z3','Sony Next Gen Smartphone','Dimensions: 146 x 72 x 7.3 mm','Memory: 3GB RAM + 32GB Internal memory. Supports microSD up to 128GB','Battery: 3100 mAh','Display: 5.2\" Full HD Super AMOLED (1920x1080 pixels)',850,'images/hp_sony_xperia_z3.jpg',16),(5,3,'Samsung','M3 Portable Hard Drive','Designed to securely store photos, music or other data','Dimension: 82x17.5x112 (WxHxD)','SafetyKey protection for your data','Capacity: 1TB','Various colour to choose',90,'images/mem_samsung_1TB_M3.jpg',12),(6,3,'SanDisk','Cruzer Micro USB flash drive','Carry Your Personal Data Wherever You Go','Dimension: 2.3 x 0.4 x 0.8 inches','Compatibility: USB 2.0/3.0','Capacity: 4GB','Various colour to choose',20,'images/mem_4GB_Cruzer_drive.jpg',18),(7,7,'Samsung','55 UHD 4K Flat Smart TV','UHD upscaling enhances the quality of all of your viewing','Resolution: 3840 x 2160','Screen Size: 55\'\'','Ultra Clear Panel: Yes','Various colour to choose',2899,'images/tv_flat_smart_55_uhd.jpg',19),(8,7,'Panasoni','58-inch AX800 Series','Experience 4K Ultra HD, clarity 4 times higher than 1080p','Resolution: 3840 x 2160','Screen Size: 58\'\'','4K Ultra HD: Yes','Various colour to choose',2999,'images/tv_panasonic_uhd_tv.jpg',16),(9,12,'Gigabyte','GA-X58A-UD7','Gigabyte Next Gen Motherboard','Chipset: Intel X58 + ICH10R Chipset','Memory: Support DDR3 2200/1333 MHz modules','ATX Form Factor: 30.5cm x 24.4cm','Various speed to choose',599,'images/ic_gigabyte_X58A_UD7.jpg',16),(10,12,'Corsair','Vengeance Pro Series 32GB DDR3 DRAM','Corsair Next Gen Memory','Density: 32GB(4x8GB)','Speed: 1866MHz','Tested Latency: 9-10-9-27','Various speed to choose',399,'images/ic_vengeance.jpg',14),(12,10,'Sennheiser','CX 1.00','Sennheiser Next Gen Earphone','Earphones with powerful sound and deep bass','Ultra small design for excellent comfort','2 year warranty','Various colour to choose',89,'images/audio_CX100.jpg',16),(13,10,'Sonic Gear','Armaggeddon A3','Sonic Gear Next Gen Speaker','Freqency Response: 40Hz - 20 KHz','Bass and Treble Volume Control','Control: Master Volume / Bass / Treble','Various colour to choose',79,'images/audio_Armaggeddon_A3.jpg',13),(14,14,'Dell','UltraSharp 25 Monitor','Dell Next Gen Monitor','In-plane switching, anti glare with hard coat 3H','Widescreen Flat Panel Display','HDMI x2, Mini DisplayPort x1, Audio out x1, USB 3.0 x5','Various colour to choose',299,'images/mon_Dell_UltraSharp_25.jpg',16),(15,14,'Samsung','27\" Minimalist FHD LED Monitor','Samsung Next Gen Monitor','Viewing Angle (H/V): 178°/178°','Contrast Ratio: 3,000:1','Response Time: 4(GTG) ms','Various colour to choose',499,'images/mon_Minimalist_FHD.jpg',14),(16,15,'Thermaltake ','MEKA G1','Thermaltake Next Gen Keyboard','Membrane: Mechanical, cherry black','Polling Rate: 1000 hz','DIMENSION(LxWxH): 430 X 160 X 40mm','Various colour to choose',179,'images/kbm_MEKA_G1.jpg',19),(17,15,'Turtle Beach','GRIP 500 Laser Gaming Mouse','Turtle Beach Next Gen Mouse','Avago 9800 laser sensors and Omron switches','Independently adjust X and Y DPI (up to 8200 DPI)','Soft-touch coating, enhances grip control','Various colour to choose',139,'images/kbm_GRIP_500.jpg',17),(18,15,'Thermaltake','Commander','Thermaltake Next Gen Mouse','Offering comfortable palm grips ','DPI: 2400','Dimension: 122 x 76 x 49mm','Various colour to choose',159,'images/kbm_commander.jpg',20);
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transaction`
--

DROP TABLE IF EXISTS `transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transaction` (
  `transactionID` int(11) NOT NULL AUTO_INCREMENT,
  `memid` int(11) NOT NULL,
  `totalprice` int(11) NOT NULL,
  `cctype` varchar(45) NOT NULL,
  `ccnum` varchar(16) NOT NULL,
  `ccname` varchar(45) NOT NULL,
  `expdateM` int(2) NOT NULL,
  `expdateY` int(2) NOT NULL,
  `cvcnum` int(5) NOT NULL,
  `vcode` varchar(20) NOT NULL,
  `transdate` varchar(30) NOT NULL,
  PRIMARY KEY (`transactionID`,`memid`),
  KEY `memid_idx` (`memid`),
  CONSTRAINT `memid` FOREIGN KEY (`memid`) REFERENCES `member` (`memid`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaction`
--

LOCK TABLES `transaction` WRITE;
/*!40000 ALTER TABLE `transaction` DISABLE KEYS */;
INSERT INTO `transaction` VALUES (34,34,783,'Visa','4716720302472071','Sly Poon',12,16,431,'-','2015-08-10 19:54:52'),(35,34,0,'Visa','4716720302472071','Sly Poon',7,16,641,'-','2015-08-10 19:58:33'),(36,34,168,'Visa','4716720302472071','Sly Poon',7,16,386,'-','2015-08-10 20:01:02'),(37,34,1044,'Visa','4716720302472071','Sly Poon',4,16,278,'79zjwL','2015-08-10 20:01:59'),(38,37,2374,'Diners Club','36367606693266','Hao Jun',5,17,265,'-','2015-08-10 21:48:56'),(39,37,21293,'America Express','378400806836967','Hao Jun',5,18,175,'-','2015-08-10 21:54:18'),(40,37,1834,'America Express','378400806836967','Hao Jun',4,17,275,'-','2015-08-10 22:01:08'),(41,37,4236,'Diners Club','36367606693266','Hao Jun',8,17,374,'-','2015-08-10 22:05:02'),(42,37,6774,'MasterCard','5513167270411966','Hao Jun',3,17,831,'-','2015-08-10 22:07:57'),(43,37,4648,'Visa','4716720302472071','Hao Jun',4,18,175,'3lGyU4','2015-08-10 22:11:07');
/*!40000 ALTER TABLE `transaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `transaction_has_confirmpurchase`
--

DROP TABLE IF EXISTS `transaction_has_confirmpurchase`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transaction_has_confirmpurchase` (
  `transactionID` int(11) NOT NULL,
  `memid` int(11) NOT NULL,
  `confirmpurchaseID` int(11) NOT NULL,
  `prodid` int(11) NOT NULL,
  `brand` varchar(45) NOT NULL,
  `prodname` varchar(45) NOT NULL,
  `unitprice` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `subtotal` int(11) NOT NULL,
  `purchasedate` varchar(30) NOT NULL,
  PRIMARY KEY (`transactionID`,`confirmpurchaseID`),
  KEY `transactionconfirm_memid_idx` (`memid`),
  KEY `transactionconfirm_confirmpurchaseID_idx` (`confirmpurchaseID`),
  CONSTRAINT `transactionconfirm_confirmpurchaseID` FOREIGN KEY (`confirmpurchaseID`) REFERENCES `confirmpurchase` (`confirmpurchaseID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `transactionconfirm_transactionID` FOREIGN KEY (`transactionID`) REFERENCES `transaction` (`transactionID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `transaction_has_confirmpurchase`
--

LOCK TABLES `transaction_has_confirmpurchase` WRITE;
/*!40000 ALTER TABLE `transaction_has_confirmpurchase` DISABLE KEYS */;
INSERT INTO `transaction_has_confirmpurchase` VALUES (34,34,280,6,'SanDisk','Cruzer Micro USB flash drive',20,1,20,'2015-08-10 19:54:52'),(34,34,281,9,'Gigabyte','GA-X58A-UD7',599,1,599,'2015-08-10 19:54:52'),(34,34,282,16,'Thermaltake ','MEKA G1',179,1,179,'2015-08-10 19:54:52'),(35,34,283,4,'Sony','Xperia Z3',850,1,850,'2015-08-10 19:58:33'),(35,34,284,7,'Samsung','55 UHD 4K Flat Smart TV',2899,1,2899,'2015-08-10 19:58:33'),(35,34,285,12,'Sennheiser','CX 1.00',89,1,89,'2015-08-10 19:58:33'),(36,34,286,12,'Sennheiser','CX 1.00',89,1,89,'2015-08-10 20:01:03'),(36,34,287,13,'Sonic Gear','Armaggeddon A3',79,1,79,'2015-08-10 20:01:03'),(37,34,288,3,'Samsung','Galaxy Note 4',900,1,900,'2015-08-10 20:01:59'),(37,34,289,6,'SanDisk','Cruzer Micro USB flash drive',20,1,20,'2015-08-10 20:01:59'),(37,34,290,17,'Turtle Beach','GRIP 500 Laser Gaming Mouse',139,1,139,'2015-08-10 20:01:59'),(38,37,291,9,'Gigabyte','GA-X58A-UD7',599,3,1797,'2015-08-10 21:48:56'),(38,37,292,10,'Corsair','Vengeance Pro Series 32GB DDR3 DRAM',399,1,399,'2015-08-10 21:48:56'),(38,37,293,12,'Sennheiser','CX 1.00',89,2,178,'2015-08-10 21:48:56'),(39,37,294,1,'Asus','N56VB-S4041H-16GB',1299,3,3897,'2015-08-10 21:54:18'),(39,37,295,3,'Samsung','Galaxy Note 4',900,6,5400,'2015-08-10 21:54:18'),(39,37,296,8,'Panasoni','58-inch AX800 Series',2999,4,11996,'2015-08-10 21:54:18'),(40,37,297,5,'Samsung','M3 Portable Hard Drive',90,4,360,'2015-08-10 22:01:08'),(40,37,298,14,'Dell','UltraSharp 25 Monitor',299,4,1196,'2015-08-10 22:01:08'),(40,37,299,17,'Turtle Beach','GRIP 500 Laser Gaming Mouse',139,2,278,'2015-08-10 22:01:09'),(41,37,300,4,'Sony','Xperia Z3',850,3,2550,'2015-08-10 22:05:02'),(41,37,301,5,'Samsung','M3 Portable Hard Drive',90,1,90,'2015-08-10 22:05:02'),(41,37,302,10,'Corsair','Vengeance Pro Series 32GB DDR3 DRAM',399,4,1596,'2015-08-10 22:05:02'),(42,37,303,3,'Samsung','Galaxy Note 4',900,7,6300,'2015-08-10 22:07:57'),(42,37,304,13,'Sonic Gear','Armaggeddon A3',79,6,474,'2015-08-10 22:07:57'),(43,37,305,2,'HP','N56VB-S4041H-16GB',1399,1,1399,'2015-08-10 22:11:07'),(43,37,306,5,'Samsung','M3 Portable Hard Drive',90,3,270,'2015-08-10 22:11:07'),(43,37,307,15,'Samsung','27\" Minimalist FHD LED Monitor',499,6,2994,'2015-08-10 22:11:07');
/*!40000 ALTER TABLE `transaction_has_confirmpurchase` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'spit'
--

--
-- Dumping routines for database 'spit'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-08-10 22:26:58
